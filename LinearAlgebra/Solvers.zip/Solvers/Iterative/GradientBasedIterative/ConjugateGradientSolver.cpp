//
// Created by hal9000 on 7/27/23.
//

#include "ConjugateGradientSolver.h"


namespace LinearAlgebra {
    ConjugateGradientSolver::ConjugateGradientSolver(VectorNormType normType, double tolerance,
                                                     unsigned int maxIterations, bool throwExceptionOnMaxFailure, ParallelizationMethod parallelizationMethod) :
                                                     IterativeSolver(normType, tolerance, maxIterations, throwExceptionOnMaxFailure, parallelizationMethod) {
        _solverName = "Conjugate Gradient";
    }

    void ConjugateGradientSolver::_initializeVectors() {
        auto n = _linearSystem->matrix->numberOfRows();
        _xNew = make_shared<vector<double>>(n);
        _xOld = make_shared<vector<double>>(n);
        _residualOld = make_shared<vector<double>>(n);
        _residualNew = make_shared<vector<double>>(n);
        _directionVectorNew = make_shared<vector<double>>(n);
        _directionVectorOld = make_shared<vector<double>>(n);
        _difference = make_shared<vector<double>>(n);
        _matrixVectorMultiplication = make_shared<vector<double>>(n);
        _vectorsInitialized = true;
    }
    
    void ConjugateGradientSolver::_iterativeSolution() {
        auto start = std::chrono::high_resolution_clock::now();
        unsigned n = _linearSystem->matrix->numberOfRows();
        
        if (_parallelization == Wank) {
            _singleThreadSolution();
        }
        if (_parallelization == vTechKickInYoo) {
            auto numberOfThreads = std::thread::hardware_concurrency();
            _printMultiThreadInitializationText(numberOfThreads);
            while (_iteration < _maxIterations && _exitNorm >= _tolerance) {
                _multiThreadSolution(numberOfThreads, n);
                _exitNorm = _calculateNorm();
                _printIterationAndNorm();
                _iteration++;
            }

        }

        else if (_parallelization == turboVTechKickInYoo) {

            double *d_matrix = _linearSystem->matrix->getArrayPointer();
            double *d_rhs = _linearSystem->rhs->data();
            double *d_xOld = _xOld->data();
            double *d_xNew = _xNew->data();
            int vectorSize = static_cast<int>(_linearSystem->rhs->size());

    

        }

        auto end = std::chrono::high_resolution_clock::now();
        printAnalysisOutcome(_iteration, _exitNorm, start, end);
    }

    void ConjugateGradientSolver::_multiThreadSolution(const unsigned short &availableThreads,
                                                       const unsigned short &numberOfRows) {
        
    }

    void ConjugateGradientSolver::_cudaSolution() {
        IterativeSolver::_cudaSolution();
    }

    void ConjugateGradientSolver::_singleThreadSolution() {
        _printSingleThreadInitializationText();
        auto start = std::chrono::high_resolution_clock::now();
        double alpha = 0.0;
        double beta = 0.0;
        _exitNorm = 1.0;
        //Calculate the initial residual

        auto lol = _linearSystem->matrix->isSymmetric();
        //_linearSystem->matrix->print(10);
        setInitialSolution(0);
        //A * x_old
        VectorOperations::matrixVectorMultiplication(_linearSystem->matrix, _xOld, _matrixVectorMultiplication);
        //r_old = b - A * x_old
        VectorOperations::subtract(_linearSystem->rhs, _matrixVectorMultiplication, _residualOld);
        double normInitial = VectorNorm(_residualOld, _normType).value();
        _residualNorms->push_back(normInitial);
        //d_old = r_old
        VectorOperations::deepCopy(_residualOld, _directionVectorOld);

        while (_iteration < _maxIterations && _exitNorm >= _tolerance) {
            //auto matrixTimesDirection = make_shared<vector<double>>(_linearSystem->matrix->numberOfRows(), 0);
            VectorOperations::matrixVectorMultiplication(_linearSystem->matrix, _directionVectorOld, _matrixVectorMultiplication);
            //Calculate the step size
            //alpha = (r_old, r_old)/(difference, A * difference)
            alpha = VectorOperations::dotProductWithTranspose(_residualOld) / VectorOperations::dotProduct(_directionVectorOld, _matrixVectorMultiplication);
            //alpha = VectorOperations::dotProduct(_residualOld, _residualOld) / VectorOperations::dotProduct(_directionVectorOld, matrixTimesDirection);
            //x_new = x_old + alpha * difference
            VectorOperations::addScaledVector(_xOld, _directionVectorOld, _xNew, alpha);
            //r_new = r_old - alpha * A * difference
            VectorOperations::subtractScaledVector(_residualOld, _matrixVectorMultiplication, _residualNew, alpha);
            
            VectorOperations::subtract(_xNew, _xOld, _difference);
            
            //Calculate the norm of the residual
            //_exitNorm = VectorNorm(_difference, _normType).value();
            _exitNorm = VectorNorm(_residualNew, _normType).value() / normInitial;
            //_exitNorm = VectorNorm(_residualNew, _normType).value();
            _residualNorms->push_back(_exitNorm);
            if (_exitNorm > _tolerance){
                //beta = (r_new, r_new)/(r_old, r_old)
                beta = VectorOperations::dotProduct(_residualNew, _residualNew) / VectorOperations::dotProduct(_residualOld, _residualOld);
                //beta = VectorOperations::dotProductWithTranspose(_residualNew) / VectorOperations::dotProductWithTranspose(_residualOld);
                //newDirection = r_new + beta * difference
                VectorOperations::addScaledVector(_residualNew, _directionVectorOld, _directionVectorNew, beta);
                
                VectorOperations::deepCopy(_residualNew, _residualOld);
                VectorOperations::deepCopy(_directionVectorNew, _directionVectorOld);
            }
            
            //Update the old residual and the old difference
            VectorOperations::deepCopy(_xNew, _xOld);
            
            
            _printIterationAndNorm(100) ;
            _iteration++;
        }
        auto end = std::chrono::high_resolution_clock::now();
    };


} // LinearAlgebra